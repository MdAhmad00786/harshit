#!/bin/bash

string="hello how are you"
for word in $string;
do echo "$word";
done
