#!/bin/bash

echo "Enter first numbers: "
read num1

echo "Enter second numbers: "
read num2

echo "Enter third numbers: "
read num3

if [ $num1 -gt $num2 ] && [ $num1 -gt $num3 ]
then
    echo "$num1 is the largest."
elif [ $num2 -gt $num1 ] && [ $num2 -gt $num3 ]
then
    echo "$num2 is the largest."
else
    echo "$num3 is the largest."
fi

